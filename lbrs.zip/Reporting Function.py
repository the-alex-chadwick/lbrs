#Reporting functions that creates a text report of possible malicious activity
#Gives details of files, timestamps and possible entryways through ports
import datetime from datetime
reportpath = input('Enter the file path of the Log Report function: ')
linecount = 0

def report(reportpath):
    with open(logfilepath, 'r') as l:
        while linecount <= 3:
            lines = l.read().splitlines()
            last_line = lines[-1]
            linecount += 1

    with open(reportpath), 'x') as r:
        report_format = (str(datetime.now().strftime("%Y-%m-%d %H:%M:%S ")) + 'Suspicious Event Ocurred' + (event.src_path) + '\n' + last_line)
