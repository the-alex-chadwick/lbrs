import time
from watchdog.observers import Observer
from watchdog.events import PatternMatchingEventHandler
from datetime import datetime
import easygui
import smtplib
import ssl
import socket
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
from fpdf import FPDF

#Reset counter and open ports
counter = 0
ports = ('')

#Variables cass, so that static variables can be referenced in any definition (saves on global usage)
#Uses easy GUI to ask for info and credentials https://pythonhosted.org/easygui/index.html
class Variables:
    port = 465
    counterlimit = 4
    email = easygui.enterbox("Enter a contact email")
    passw = easygui.passwordbox("Enter email password")
    path = easygui.diropenbox("Add a file path to watch", "Watched Directory")
    reportpath = easygui.fileopenbox ("Add a report file path", "Report file")
    logfilepath = easygui.fileopenbox("Add a log file", "Log File")



def main():
    setup()

#Setup variables for the watchdog package, referencing definitions and handler https://pythonhosted.org/watchdog/
def setup():
    path = Variables.path
    print("Ok running LBRS")
    patterns = "*"
    ignore_patterns = ""
    ignore_directories = False
    case_sensitive = True
    my_event_handler = PatternMatchingEventHandler(patterns, ignore_patterns, ignore_directories, case_sensitive)
    my_event_handler.on_created = on_created
    my_event_handler.on_deleted = on_deleted
    my_event_handler.on_modified = on_modified
    my_event_handler.on_moved = on_moved
#Recursive and will go into sub-directories
    go_recursively = True
    my_observer = Observer()
    my_observer.schedule(my_event_handler, path, recursive=go_recursively)

    my_observer.start()

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        my_observer.stop()
        my_observer.join()

#Definitions for whenever a file or folder is created, will add to counter and call rule set
#Writes to designated log file when file event occurs
def on_created(event):
    global counter
    log = Variables.logfilepath
    cr_format = (str(datetime.now().strftime("%Y-%m-%d %H:%M:%S ")) + ' Added: ' + (event.src_path) + '\n')
    with open(log, 'a') as f:
        f.write(cr_format)
        f.close()
    counter += 1
    print('ct is: ' + str(counter))
    ruleset(event)

#Whenever a file or folder is deleted ""
def on_deleted(event):
    global counter
    log = Variables.logfilepath
    del_format = (str(datetime.now().strftime("%Y-%m-%d %H:%M:%S ")) + ' Deleted ' + (event.src_path) + '\n')
    with open(log, 'a') as d:
        d.write(del_format)
        d.close()
    counter += 1
    ruleset(event)

#Whenever a file or folder is moved source and destination path included in log file
def on_moved(event):
    global counter
    log = Variables.logfilepath
    mov_format = (str(datetime.now().strftime("%Y-%m-%d %H:%M:%S ")) + ' Moved: ' + (event.src_path) + ' To: ' + (event.dest_path) + '\n')
    with open(log, 'a') as m:
        m.write(mov_format)
        m.close()
    counter += 1
    ruleset(event)

#Whenver a file is edited, will call event
def on_modified(event):
    global counter
    log = Variables.logfilepath
    mod_format = (str(datetime.now().strftime("%Y-%m-%d %H:%M:%S ")) + 'Modified: ' + (event.src_path) + '\n')
    with open (log, 'a') as mo:
        mo.write(mod_format)
        mo.close()
    counter += 1
    ruleset(event)

#Simple ruleset called and checks counter against set limit of changes
def ruleset(event):
    global counter
    ctl = Variables.counterlimit
    if counter > ctl:
        print(counter)
        warning(event)
        counter = 0

#Warning event display GUI popup after called from ruleset check
def warning(event):
    path = Variables.path
    easygui.msgbox("Warning activity in" + path, title="Warning")
    report(event)

#Report function runs a port check https://www.pythonforbeginners.com/code-snippets-source-code/port-scanner-in-python/
# and creates a report of data gathered from a linecount of log file last 5 lines
def report(event):
    global ports
    localip = (socket.gethostbyname(socket.gethostname()))
    for port in range(1, 1025):
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(1)
        result = sock.connect_ex((localip, port))
        if 0 == result:
            open_ports = ("Port: {} Open".format(port))
            ports = (str(open_ports))

    reportfile = Variables.reportpath
    log = Variables.logfilepath
    print(ports)

    filehandler = open(log, 'r')
    linelist = filehandler.readlines()
    filehandler.close()
    line1 = linelist[len(linelist)-1]
    line2 = linelist[len(linelist)-2]
    line3 = linelist[len(linelist)-3]
    line4 = linelist[len(linelist)-4]
    line5 = linelist[len(linelist)-5]

#Report format structure including last lines of log file and timestamps, as well as gathered open ports
#Using pyfpdf https://pyfpdf.readthedocs.io/en/latest/
    format = (str(datetime.now().strftime("%Y-%m-%d %H:%M:%S ")) + (event.src_path) + '\n')
    pdf = FPDF(orientation='P', unit='mm', format='A4')
    pdf.add_page()
    pdf.set_font('Arial', size = 12)
    pdf.cell(200, 10, txt='Log File Report', ln=1, align='C')
    pdf.cell(200, 10, txt= "A detailed report of possible malicious activity", ln=1, align='C')
    pdf.cell(200,10, txt= ("Occurred at: " + str(datetime.now().strftime("%Y-%m-%d %H:%M:%S"))), ln=1)
    pdf.cell(200,10,txt=("Log 1: " + line5), ln=1)
    pdf.cell(200, 10, txt=("Log 2: " + line4),ln=1)
    pdf.cell(200, 10, txt=("Log 3: " + line3),ln=1)
    pdf.cell(200, 10, txt=("Log 4: " + line2), ln=1)
    pdf.cell(200, 10, txt=("Log 3: " + line1), ln=1)
    pdf.cell(200,10,txt=("Open Ports: " + ports),ln=1)

    pdf.output(reportfile)
    email()

#Email function retrieves user gmail login and will login from a session
#Report is attached and encoded to an email which is sent to itself called after report is created
#Uses Smtplib https://docs.python.org/3/library/smtplib.html
def email():
    port = Variables.port
    context = ssl.create_default_context()
    em = Variables.email
    emp = Variables.passw
    msg1 = MIMEMultipart()
    subject = "File system email report with PDF"
    body = 'This is a log file report'
    sender = "watchdogtest8761@gmail.com"
    receiver = em
    msg1["From"] = sender
    msg1["To"] = receiver
    msg1["Subject"] = subject
    msg1.attach(MIMEText(body, 'plain'))
    reportname = Variables.reportpath

    with open (reportname, "rb") as attachment:
        part = MIMEBase("application", "octet-stream")
        part.set_payload(attachment.read())
    encoders.encode_base64(part)
    part.add_header(
        "Content-Disposition",
        "attachment",
        filename= "Report_PDF.pdf"
    )
    msg1.attach(part)
    text = msg1.as_string()

    with smtplib.SMTP_SSL('smtp.gmail.com', port, context=context) as s:
        s.login(em, emp)
        s.sendmail(em, em, text)
        s.quit()


if __name__ == "__main__":
    main()
