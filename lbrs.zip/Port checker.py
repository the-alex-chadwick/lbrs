#Checks open ports on the localhost for the reporting function

import socket
localip = (socket.gethostbyname(socket.gethostname()))
for port in range(1, 1025):
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(1)
    result = sock.connect_ex((localip, port))
    if 0 == result:
        open_ports = ("Port: {} Open".format(port))
        ports = (str(open_ports))
        print(ports)